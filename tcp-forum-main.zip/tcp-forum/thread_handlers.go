package main

import (
	"net/http"
	"time"

	"github.com/gin-contrib/sessions"
	"github.com/gin-gonic/gin"
	"go.mongodb.org/mongo-driver/bson/primitive"
)

// ThreadForm struct representing the form data submitted by users when creating a thread
type ThreadForm struct {
	Title   string `form:"title" binding:"required"`
	Content string `form:"content" binding:"required"`
}

// getCurrentUser retrieves the currently logged-in user from the session
func getCurrentUser(c *gin.Context) User {
	session := sessions.Default(c)
	userData := session.Get("user")

	// Check if the user data exists in the session
	if userData != nil {
		if user, ok := userData.(User); ok {
			return user
		}
	}

	// If the user data is not found or is invalid, return an empty User struct
	return User{}
}

func createThreadHandlerPage(c *gin.Context) {
	c.HTML(http.StatusOK, "create_thread.html", nil)
}

func createThreadHandler(c *gin.Context) {
	// Bind the form data to the ThreadForm struct
	var threadForm ThreadForm
	if err := c.ShouldBind(&threadForm); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": "Invalid request payload"})
		return
	}

	// Create a new Thread instance
	thread := Thread{
		ID:        primitive.NewObjectID(),
		Title:     threadForm.Title,
		Content:   threadForm.Content,
		CreatedBy: getCurrentUser(c),
		CreatedAt: time.Now().Format("2006-01-02 15:04:05"),
	}

	// Append the new thread to the threads slice
	threads = append(threads, thread)

	// Redirect to the home page
	c.Redirect(http.StatusFound, "/")
}
