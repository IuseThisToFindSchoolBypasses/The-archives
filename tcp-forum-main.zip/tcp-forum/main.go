package main

import (
	"context"
	"log"
	"net/http"

	"github.com/gin-contrib/sessions"
	"github.com/gin-contrib/sessions/cookie"
	"github.com/gin-gonic/gin"
	"go.mongodb.org/mongo-driver/bson/primitive"
	"go.mongodb.org/mongo-driver/mongo"
	"go.mongodb.org/mongo-driver/mongo/options"
)

type Thread struct {
	ID        primitive.ObjectID `json:"id" bson:"_id,omitempty"`
	Title     string             `json:"title"`
	Content   string             `json:"content"`
	CreatedBy User               `json:"createdBy"`
	CreatedAt string             `json:"createdAt"`
}

func main() {

	router := gin.Default()

	// Set the location of your HTML templates and static files
	router.LoadHTMLGlob("templates/*.html")
	router.Static("/static", "./static")

	// Initialize sessions
	store := cookie.NewStore([]byte("secret"))
	router.Use(sessions.Sessions("session", store))

	// Routes
	router.GET("/", homeHandler)
	router.GET("/register", registerHandlerPage)
	router.GET("/login", loginHandlerPage)
	router.POST("/register", registerHandler)
	router.POST("/login", loginHandler)
	router.GET("/logout", logoutHandler)
	router.GET("/threads", homeHandler)

	// Thread handlers
	router.GET("/create-thread", createThreadHandlerPage)
	router.POST("/create-thread", createThreadHandler)

	// Start the server
	if err := router.Run(":8080"); err != nil {
		log.Fatal(err)
	}

}

// Handler for the home page
func homeHandler(c *gin.Context) {
	// Get the "loggedIn" session variable
	session := sessions.Default(c)
	isLoggedIn := session.Get("loggedIn")

	// Check if the user is logged in
	var message string
	var showActions bool
	if isLoggedIn != nil && isLoggedIn.(bool) {
		// User is logged in, show the "Welcome to the Forum" message with the logout link
		message = "Welcome to the Forum! You are logged in."
		showActions = true
	} else {
		// User is not logged in, show a generic message
		message = "Welcome to the Forum!"
		showActions = false
	}
	client, err := mongo.Connect(context.Background(), options.Client().ApplyURI("mongodb://localhost:27017"))
	if err != nil {
		log.Fatal("Failed to connect to MongoDB:", err)
	}
	database = client.Database("forumdb")       // Replace "forumdb" with your actual database name
	collection = database.Collection("threads") // "threads" is the name of the collection to store threads

	// Retrieve the threads from the data store
	threads := getThreadsFromDataStore() // Implement the function to retrieve the threads

	c.HTML(http.StatusOK, "home.html", gin.H{
		"Message":     message,
		"ShowActions": showActions,
		"Threads":     threads, // Pass the threads to the template
	})
}

// Handler for the registration page
func registerHandlerPage(c *gin.Context) {
	c.HTML(http.StatusOK, "register.html", nil)
}

// Handler for the login page
func loginHandlerPage(c *gin.Context) {
	c.HTML(http.StatusOK, "login.html", nil)
}

var threads []Thread

func getThreadsFromDataStore() []Thread {
	return threads
}

var (
	client     *mongo.Client
	database   *mongo.Database
	collection *mongo.Collection
)
