package main

import (
	"bytes"
	"fmt"
	"io/ioutil"
	"log"
	"net/http"
	"sync"

	"github.com/gin-contrib/sessions"
	"github.com/gin-gonic/gin"
	"github.com/google/uuid"
	"github.com/prologic/bitcask"
	"golang.org/x/crypto/bcrypt"
)

type User struct {
	ID       string `form:"-"`
	Username string `form:"username" binding:"required"`
	Email    string `form:"email" binding:"required,email"`
	Password string `form:"password" binding:"required"`
}

var (
	dbMutex sync.RWMutex
	emailDB = make(map[string]bool)
)

func registerHandler(c *gin.Context) {
	// Print the raw request payload
	data, _ := c.GetRawData()
	fmt.Println("Raw request payload:", string(data))

	// Reset the request body so it can be bound again
	c.Request.Body = ioutil.NopCloser(bytes.NewBuffer(data))

	var user User
	if err := c.ShouldBind(&user); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": "Invalid request payload"})
		return
	}
	// Debug output
	fmt.Println("Received user data:", user)

	// Retrieve the Bitcask database instance
	db, err := initializeDatabase()
	if err != nil {
		log.Fatal(err)
	}
	defer db.Close()

	// Check if the username already exists
	existingUser, err := db.Get([]byte(user.Username))
	if err == nil && existingUser != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": "Username already exists"})
		return
	}

	// Check if the email already exists
	if emailExists(user.Email) {
		c.JSON(http.StatusBadRequest, gin.H{"error": "Email already exists"})
		return
	}

	// Encrypt the password
	hashedPassword, err := encryptPassword(user.Password)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "Failed to encrypt password"})
		return
	}

	// Generate a unique user ID
	user.ID = uuid.New().String()

	// Store the user in the Bitcask database
	err = db.Put([]byte(user.Username), []byte(hashedPassword))
	if err != nil {
		log.Println("Failed to store user in the database:", err)
		c.JSON(http.StatusInternalServerError, gin.H{"error": "Failed to register user"})
		return
	}

	// Add the email to the database
	addEmail(user.Email)

	// Set a success flash message
	session := sessions.Default(c)
	session.AddFlash("SUCCESS! YOU CAN NOW LOGIN!")

	// Save the session
	if err := session.Save(); err != nil {
		log.Println("Failed to save session:", err)
	}

	// Redirect to the login page
	c.Redirect(http.StatusFound, "/login")
}

func emailExists(email string) bool {
	dbMutex.RLock()
	defer dbMutex.RUnlock()

	_, exists := emailDB[email]
	return exists
}

func addEmail(email string) {
	dbMutex.Lock()
	defer dbMutex.Unlock()

	emailDB[email] = true
}

func initializeDatabase() (*bitcask.Bitcask, error) {
	db, err := bitcask.Open("database")
	if err != nil {
		return nil, err
	}

	return db, nil
}

func loginHandler(c *gin.Context) {
	var loginData struct {
		Username string `form:"username" binding:"required"`
		Password string `form:"password" binding:"required"`
	}
	if err := c.ShouldBind(&loginData); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": "Invalid request payload"})
		return
	}

	// Retrieve the user from the Bitcask database based on the username
	db, err := initializeDatabase()
	if err != nil {
		log.Fatal(err)
	}
	defer db.Close()

	// Check if the user exists
	hashedPassword, err := db.Get([]byte(loginData.Username))
	if err != nil {
		c.JSON(http.StatusUnauthorized, gin.H{"error": "Invalid credentials"})
		return
	}

	// Compare the provided password with the stored hashed password
	if err := comparePasswords(string(hashedPassword), loginData.Password); err != nil {
		c.JSON(http.StatusUnauthorized, gin.H{"error": "Invalid credentials"})
		return
	}

	// Set the "loggedIn" session variable to true
	session := sessions.Default(c)
	session.Set("loggedIn", true)
	if err := session.Save(); err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "Failed to set session variable"})
		return
	}

	// Redirect to the home page
	c.Redirect(http.StatusFound, "/")
}

func encryptPassword(password string) (string, error) {
	hashedPassword, err := bcrypt.GenerateFromPassword([]byte(password), bcrypt.DefaultCost)
	if err != nil {
		return "", err
	}
	return string(hashedPassword), nil
}

func comparePasswords(hashedPassword, password string) error {
	return bcrypt.CompareHashAndPassword([]byte(hashedPassword), []byte(password))
}
func logoutHandler(c *gin.Context) {
	session := sessions.Default(c)
	session.Clear()
	if err := session.Save(); err != nil {
		log.Println("Failed to clear session:", err)
	}

	// Redirect to the login page
	c.Redirect(http.StatusFound, "/login")
}
