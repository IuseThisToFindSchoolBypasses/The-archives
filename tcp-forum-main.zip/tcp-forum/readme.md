# TCP-Forum
### a modern day replacement to the mybb bullshit we see all the time, with privacy and security by design and not as a feature

## Prerequisites

- Go 1.20.3 or higher
- MongoDB

## Installation
1. Setup your MongoDB shit for the threads handling
```shell
mongo --host 127.0.0.1 --port 27017
```

2. Clone the repository:


```shell
git clone https://git.tcp.direct/s4d/tcp-forum.git
cd tcp-forum
go mod download
go mod tidy
go run main.go
```


## Features

* User registration: Users can create new accounts by providing their username, email, and password.
* User login: Registered users can log in using their credentials.
* User logout: Logged-in users can log out of their accounts.
* Thread creation: Logged-in users can create new threads by providing a title and content.
* Thread listing: The home page displays a list of existing threads, including the title, content, creator, and creation timestamp.
    
## Project Structure

The project structure follows a typical Go application layout:

* main.go: The entry point of the application, containing the main function and routing setup.
* handlers.go: Contains the request handlers for user registration, login, and logout.
* thread_handlers.go: Contains the request handlers for thread creation and listing.
* templates/: Directory containing HTML templates used for rendering the web pages.
* static/: Directory for storing static files such as CSS stylesheets and JavaScript files.

## Contributing

Contributions are welcome and incouraged! If you find any issues or have suggestions for improvements, please open an issue or submit a pull request.